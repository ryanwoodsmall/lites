#define __INLINE__

#include <sys/param.h>
#include <sys/vnode.h>
