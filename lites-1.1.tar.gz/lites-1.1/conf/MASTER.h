/* 
 * Mach Operating System
 * Copyright (c) 1994 Johannes Helander
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify and distribute this software and its
 * documentation is hereby granted, provided that both the copyright
 * notice and this permission notice appear in all copies of the
 * software, derivative works or modified versions, and any portions
 * thereof, and that both notices appear in supporting documentation.
 * 
 * JOHANNES HELANDER ALLOWS FREE USE OF THIS SOFTWARE IN ITS "AS IS"
 * CONDITION.  JOHANNES HELANDER DISCLAIMS ANY LIABILITY OF ANY KIND
 * FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
 */
/*
 * HISTORY
 * $Log: $
 */
/* 
 *	File:	conf/MASTER
 *	Author:	Johannes Helander, Helsinki University of Technology, 1994.
 *
 *	Standard Configuration Components
 */

/*   Options that must always be there */
#define	SERVER	lites+mtime+muarea+file_ports+vnpager+old_synch

/*  Minimal configuration */
#define	BOOT	SERVER+ether+inet+ffs+pty

/*  Standard configuration */
#define	STD	BOOT+second_server+syscalltrace+compat_43+compat_oldsock+kernfs+nfs+atsys

/*  Everything that is known to work */
#define	LARGE	STD+union

#define	DEBUG	debug+machid_register+lineno+diagnostic+assertions+queue_assertions+mutex_holder_assert

/*  Compiles but untested. */
#define	UNTESTED mfs+umapfs+fdesc+cd9660+portal+lfs+sl+ns+nsip+lfs+quota+gateway+mrouting

/*  Unimplemented or does not compile. */
#define	ALMOST	ccitt+hdlc+iso+tpip+eon
#define	NOTYET	llc+procfs+sysvshm

/* Move options from NOTYET to ALMOST to UNTESTED to LARGE as work progresses.
*/
