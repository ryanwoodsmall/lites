/* $Header: /n/fast/usr/lsrc/mach/CVS/lites/server/netiso/xebec/malloc.h,v 1.1.1.1 1995/03/02 21:49:57 mike Exp $ */
/* $Source: /n/fast/usr/lsrc/mach/CVS/lites/server/netiso/xebec/malloc.h,v $ */

char *Malloc();
