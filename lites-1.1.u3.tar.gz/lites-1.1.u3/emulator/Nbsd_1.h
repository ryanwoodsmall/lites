/*
 * XXX temporary XXX
 *
 * Will be replaced by flick generated version (with all the prototypes) soon.
 * The prototypes below are needed for e_bsd.c.
 */

extern kern_return_t bsd_write_short();

extern kern_return_t bsd_sendmsg_short();

